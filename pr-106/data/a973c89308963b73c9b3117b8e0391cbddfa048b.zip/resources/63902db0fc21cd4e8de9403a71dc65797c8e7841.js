__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/0t05k9vhsj5bx.js",
  "static/chunks/3m2pfqp1esdr0.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/395bc3h0uidu4.js",
  "static/chunks/turbopack-2ojw6o78nodrc.js"
])
