__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/3o9b50i89_s29.js",
  "static/chunks/3m2pfqp1esdr0.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/1101y3uv3utn1.js",
  "static/chunks/turbopack-2fkiz47h9vnhm.js"
])
