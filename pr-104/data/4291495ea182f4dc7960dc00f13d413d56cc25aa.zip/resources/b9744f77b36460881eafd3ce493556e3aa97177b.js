__turbopack_load_page_chunks__("/", [
  "static/chunks/2fwi1aiph-pqz.js",
  "static/chunks/3m2pfqp1esdr0.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/3wh7yxvzm-79s.js",
  "static/chunks/turbopack-3675lpjq212pm.js"
])
