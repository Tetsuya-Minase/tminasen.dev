__turbopack_load_page_chunks__("/", [
  "static/chunks/27ux3v45iew95.js",
  "static/chunks/3m2pfqp1esdr0.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2jwzmgy3m_bc5.js",
  "static/chunks/turbopack-1lkcon6o2n783.js"
])
