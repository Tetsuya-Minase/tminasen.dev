__turbopack_load_page_chunks__("/", [
  "static/chunks/2fwi1aiph-pqz.js",
  "static/chunks/3m2pfqp1esdr0.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/1101y3uv3utn1.js",
  "static/chunks/turbopack-3n6miotq-o-42.js"
])
