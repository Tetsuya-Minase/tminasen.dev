__turbopack_load_page_chunks__("/", [
  "static/chunks/164-3l8w_62vi.js",
  "static/chunks/03._-0i~rmr6j.js",
  "static/chunks/0863fq_c5_2t8.js",
  "static/chunks/0xwb33dlr6a6y.js",
  "static/chunks/turbopack-0ktz5gqtfie89.js"
])
