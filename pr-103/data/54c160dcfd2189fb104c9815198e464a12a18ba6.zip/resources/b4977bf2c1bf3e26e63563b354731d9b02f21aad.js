__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/0gy49iv88mnfk.js",
  "static/chunks/03._-0i~rmr6j.js",
  "static/chunks/0863fq_c5_2t8.js",
  "static/chunks/0xwb33dlr6a6y.js",
  "static/chunks/turbopack-15uk34roud4pd.js"
])
