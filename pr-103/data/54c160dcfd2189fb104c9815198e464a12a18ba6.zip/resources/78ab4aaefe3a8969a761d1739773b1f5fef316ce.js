__turbopack_load_page_chunks__("/", [
  "static/chunks/00hzjbnwl9i6u.js",
  "static/chunks/03._-0i~rmr6j.js",
  "static/chunks/0863fq_c5_2t8.js",
  "static/chunks/0xwb33dlr6a6y.js",
  "static/chunks/turbopack-0xumt55hbi5wc.js"
])
